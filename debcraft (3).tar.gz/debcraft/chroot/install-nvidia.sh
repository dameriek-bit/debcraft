#!/usr/bin/env bash
# DebCraft — NVIDIA Driver Configuration Script (runs inside chroot)
# Configures NVIDIA drivers: Xorg config, modprobe, services, PRIME, helpers
#
# This script is called by build.sh Stage 5 when --nvidia is used.

set -e

echo "[DebCraft::NVIDIA] Configuring NVIDIA drivers..."

# =============================================================================
# Step 1: Detect NVIDIA GPU
# =============================================================================
if ! lspci 2>/dev/null | grep -qi nvidia; then
    echo "[DebCraft::NVIDIA] No NVIDIA GPU detected in this environment."
    echo "[DebCraft::NVIDIA] Drivers are installed but will activate on NVIDIA hardware."
    # Still continue setup — drivers will work when booted on real NVIDIA hardware
fi

# =============================================================================
# Step 2: Xorg configuration
# =============================================================================
echo "[DebCraft::NVIDIA] Creating Xorg configuration..."
mkdir -p /etc/X11/xorg.conf.d

cat > /etc/X11/xorg.conf.d/10-nvidia.conf << 'XORGEOF'
Section "Device"
    Identifier     "NVIDIA"
    Driver         "nvidia"
    BusID          "PCI:1:0:0"
    Option         "NoLogo"             "true"
    Option         "DRI"                "3"
    Option         "RenderAccel"        "true"
    Option         "AccelMethod"        "glamor"
    Option         "TearFree"           "true"
    Option         "Coolbits"           "28"
    Option         "RegistryDwords"     "PowerMizerEnable=0x1; PerfLevelSrc=0x3322"
    Option         "Metamodes"          "nvidia-auto-select +0+0 {ForceFullCompositionPipeline=On}"
EndSection

Section "Screen"
    Identifier     "Default Screen"
    Device         "NVIDIA"
    DefaultDepth   24
    Option         "AllowEmptyInitialConfiguration" "true"
    SubSection     "Display"
        Depth      24
        Modes      "nvidia-auto-select"
    EndSubSection
EndSection

Section "Module"
    Load           "glx"
    Load           "extmod"
EndSection

Section "Extensions"
    Option         "Composite"          "enable"
EndSection
XORGEOF

# =============================================================================
# Step 3: Modprobe configuration
# =============================================================================
echo "[DebCraft::NVIDIA] Creating modprobe configuration..."

cat > /etc/modprobe.d/nvidia.conf << 'MODPROBEEOF'
# DebCraft — NVIDIA kernel module parameters
options nvidia NVreg_DynamicPowerManagement=0x02
options nvidia NVreg_PreserveVideoMemoryAllocations=1
options nvidia_drm modeset=1
options nvidia_drm fbdev=1
options nvidia_drm commit=1
options nvidia "NVreg_RegistryDwords=PowerMizerEnable=0x1; PerfLevelSrc=0x3322"
MODPROBEEOF

# Initramfs module list
mkdir -p /etc/initramfs-tools/modules.d
cat > /etc/initramfs-tools/modules.d/nvidia.conf << 'INITRAMFSEOF'
# NVIDIA kernel modules to load early
nvidia
nvidia_modeset
nvidia_uvm
nvidia_drm
INITRAMFSEOF

# =============================================================================
# Step 4: NVIDIA persistence daemon service
# =============================================================================
echo "[DebCraft::NVIDIA] Creating nvidia-persistenced service..."

cat > /etc/systemd/system/nvidia-persistenced.service << 'SERVICEEOF'
[Unit]
Description=NVIDIA Persistence Daemon
After=nvidia-modules-load.service
Wants=nvidia-modules-load.service

[Service]
Type=forking
ExecStart=/usr/bin/nvidia-persistenced --verbose
ExecStop=/usr/bin/nvidia-persistenced --quit
PIDFile=/var/run/nvidia-persistenced/nvidia-persistenced.pid
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
SERVICEEOF

systemctl enable nvidia-persistenced 2>/dev/null || true

# =============================================================================
# Step 5: GRUB kernel parameters for DRM KMS
# =============================================================================
echo "[DebCraft::NVIDIA] Configuring GRUB kernel parameters..."

if [[ -f /etc/default/grub ]]; then
    # Add nvidia-drm.modeset=1 if not already present
    if ! grep -q "nvidia-drm.modeset=1" /etc/default/grub 2>/dev/null; then
        sed -i 's/GRUB_CMDLINE_LINUX_DEFAULT="/GRUB_CMDLINE_LINUX_DEFAULT="nvidia-drm.modeset=1 /' /etc/default/grub
    fi
fi

# =============================================================================
# Step 6: PRIME (hybrid graphics) setup
# =============================================================================
if lspci 2>/dev/null | grep -qiE 'vga.*intel|vga.*amd'; then
    echo "[DebCraft::NVIDIA] Hybrid graphics detected — configuring PRIME..."

    apt-get install -y nvidia-prime 2>/dev/null || true

    cat > /etc/prime-discrete << 'PRIMEEOF'
# DebCraft — PRIME hybrid graphics configuration
#
# Switch GPUs with:
#   sudo prime-select nvidia    (use NVIDIA GPU)
#   sudo prime-select intel     (use integrated GPU)
#   sudo prime-select query     (check current GPU)
PRIMEEOF

    # Default to NVIDIA dGPU
    prime-select nvidia 2>/dev/null || true
fi

# =============================================================================
# Step 7: Helper scripts
# =============================================================================
echo "[DebCraft::NVIDIA] Creating helper scripts..."

# nvidia-info — shows GPU info, OpenGL renderer, Vulkan, PRIME status
cat > /usr/local/bin/nvidia-info << 'HELPEREOF'
#!/usr/bin/env bash
echo "================================"
echo "  DebCraft — NVIDIA Info"
echo "================================"
echo ""

if command -v nvidia-smi &>/dev/null; then
    echo "--- Driver & GPU ---"
    nvidia-smi --query-gpu=name,driver_version,temperature.gpu,utilization.gpu,memory.used,memory.total --format=csv,noheader 2>/dev/null || nvidia-smi
    echo ""
fi

echo "--- OpenGL ---"
if command -v glxinfo &>/dev/null; then
    glxinfo 2>/dev/null | grep "OpenGL renderer" || echo "OpenGL info unavailable"
else
    echo "glxinfo not installed"
fi

echo ""
echo "--- Vulkan ---"
if command -v vulkaninfo &>/dev/null; then
    vulkaninfo --summary 2>/dev/null | grep -E "GPU|deviceName" || echo "Vulkan info unavailable"
else
    echo "vulkaninfo not installed"
fi

echo ""
echo "--- PRIME ---"
if command -v prime-select &>/dev/null; then
    echo "Active GPU: $(prime-select query 2>/dev/null || echo 'unknown')"
else
    echo "PRIME not configured"
fi
HELPEREOF
chmod +x /usr/local/bin/nvidia-info

# nvidia-power — power management helper
cat > /usr/local/bin/nvidia-power << 'HELPEREOF'
#!/usr/bin/env bash
case "${1:-}" in
    on)
        sudo nvidia-smi -pm 1
        echo "NVIDIA persistence mode: ON"
        ;;
    off)
        sudo nvidia-smi -pm 0
        echo "NVIDIA persistence mode: OFF"
        ;;
    fan)
        WATTS="${2:-100}"
        sudo nvidia-smi -pl "$WATTS"
        echo "Power limit set to ${WATTS}W"
        ;;
    status)
        nvidia-smi --query-gpu=power.draw,power.limit --format=csv,noheader 2>/dev/null || nvidia-smi -pl
        ;;
    *)
        echo "Usage: nvidia-power {on|off|fan <watts>|status}"
        echo ""
        echo "Commands:"
        echo "  on           Enable persistence mode"
        echo "  off          Disable persistence mode"
        echo "  fan <watts>  Set power limit (e.g. nvidia-power fan 80)"
        echo "  status       Show current power draw/limit"
        ;;
esac
HELPEREOF
chmod +x /usr/local/bin/nvidia-power

# =============================================================================
# Step 8: Update initramfs
# =============================================================================
echo "[DebCraft::NVIDIA] Updating initramfs with NVIDIA modules..."
update-initramfs -u -k all 2>/dev/null || true

echo "[DebCraft::NVIDIA] Configuration complete!"
echo "[DebCraft::NVIDIA] After installation, run 'nvidia-info' to verify your setup."