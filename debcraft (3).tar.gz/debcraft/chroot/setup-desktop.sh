#!/usr/bin/env bash
# DebCraft — Desktop Environment Setup Script (runs inside chroot)
# Sets up the Archcraft-like bspwm desktop with all configurations
#
# This script expects config files at /tmp/config/ (copied by build.sh)

set -e

CONFIG_SRC="/tmp/config"
ASSETS_SRC="/tmp/assets"
TARGET_USER="live"

echo "[DebCraft::Desktop] Setting up desktop environment..."

# =============================================================================
# Step 0: Ensure target user exists (may run before stage_finalize)
# =============================================================================
if ! id "${TARGET_USER}" &>/dev/null; then
    echo "[DebCraft::Desktop] Creating user '${TARGET_USER}'..."
    groupadd -r autologin 2>/dev/null || true
    useradd -m -s /bin/bash \
        -G sudo,audio,video,plugdev,netdev,cdrom,autologin "${TARGET_USER}" 2>/dev/null || true
    echo "${TARGET_USER}:${TARGET_USER}" | chpasswd
fi

# =============================================================================
# Step 1: Create XDG user directories
# =============================================================================
echo "[DebCraft::Desktop] Creating user directories..."

mkdir -p /home/${TARGET_USER}/.config
mkdir -p /home/${TARGET_USER}/.local/share
mkdir -p /home/${TARGET_USER}/.local/bin
mkdir -p /home/${TARGET_USER}/Pictures/Screenshots
mkdir -p /home/${TARGET_USER}/Pictures/Wallpapers
mkdir -p /home/${TARGET_USER}/{Desktop,Documents,Downloads,Music,Videos}
mkdir -p /home/${TARGET_USER}/.cache/polybar
mkdir -p /home/${TARGET_USER}/.cache/dunst
mkdir -p /root/.config

# =============================================================================
# Step 2: Copy configuration files to live user
# =============================================================================
echo "[DebCraft::Desktop] Copying configuration files..."

# bspwm
mkdir -p /home/${TARGET_USER}/.config/bspwm
cp -r "${CONFIG_SRC}/bspwm/"* /home/${TARGET_USER}/.config/bspwm/
chmod +x /home/${TARGET_USER}/.config/bspwm/bspwmrc

# sxhkd
mkdir -p /home/${TARGET_USER}/.config/sxhkd
cp -r "${CONFIG_SRC}/sxhkd/"* /home/${TARGET_USER}/.config/sxhkd/

# polybar
mkdir -p /home/${TARGET_USER}/.config/polybar
cp -r "${CONFIG_SRC}/polybar/"* /home/${TARGET_USER}/.config/polybar/
chmod +x /home/${TARGET_USER}/.config/polybar/launch.sh

# picom
mkdir -p /home/${TARGET_USER}/.config/picom
cp -r "${CONFIG_SRC}/picom/"* /home/${TARGET_USER}/.config/picom/

# rofi
mkdir -p /home/${TARGET_USER}/.config/rofi
cp -r "${CONFIG_SRC}/rofi/"* /home/${TARGET_USER}/.config/rofi/
chmod +x /home/${TARGET_USER}/.config/rofi/powermenu/powermenu.sh 2>/dev/null || true

# alacritty
mkdir -p /home/${TARGET_USER}/.config/alacritty
cp -r "${CONFIG_SRC}/alacritty/"* /home/${TARGET_USER}/.config/alacritty/

# dunst
mkdir -p /home/${TARGET_USER}/.config/dunst
cp -r "${CONFIG_SRC}/dunst/"* /home/${TARGET_USER}/.config/dunst/

# GTK 3 + 4
mkdir -p /home/${TARGET_USER}/.config/gtk-3.0
mkdir -p /home/${TARGET_USER}/.config/gtk-4.0
cp -r "${CONFIG_SRC}/gtk-3.0/"* /home/${TARGET_USER}/.config/gtk-3.0/
cp -r "${CONFIG_SRC}/gtk-4.0/"* /home/${TARGET_USER}/.config/gtk-4.0/

# starship
mkdir -p /home/${TARGET_USER}/.config/starship
cp -r "${CONFIG_SRC}/starship/"* /home/${TARGET_USER}/.config/starship/

# Also copy all configs to root (for consistency)
for cfg_dir in bspwm sxhkd polybar picom rofi alacritty dunst gtk-3.0 gtk-4.0 starship; do
    cp -r "/home/${TARGET_USER}/.config/${cfg_dir}" /root/.config/ 2>/dev/null || true
done

# =============================================================================
# Step 3: Set up wallpapers
# =============================================================================
echo "[DebCraft::Desktop] Setting up wallpapers..."

# Generate a gradient wallpaper using ImageMagick (if available)
if command -v convert &>/dev/null; then
    convert -size 1920x1080 gradient:'#1e1e2e'-'#0d1117' \
        -fill '#89b4fa' -font DejaVu-Sans-Bold -pointsize 72 \
        -gravity center -annotate 0 'DebCraft' \
        -fill '#cdd6f4' -font DejaVu-Sans -pointsize 24 \
        -gravity center -annotate +0+80 'Debian + Archcraft Aesthetic' \
        /home/${TARGET_USER}/Pictures/Wallpapers/debcraft-default.png 2>/dev/null || true
fi

# Copy any custom wallpapers from assets
if [[ -d "${ASSETS_SRC}/wallpapers" ]]; then
    cp "${ASSETS_SRC}/wallpapers/"* /home/${TARGET_USER}/Pictures/Wallpapers/ 2>/dev/null || true
fi

# =============================================================================
# Step 4: Configure nitrogen (wallpaper setter)
# =============================================================================
mkdir -p /home/${TARGET_USER}/.config/nitrogen

cat > /home/${TARGET_USER}/.config/nitrogen/bg-saved.cfg << NITEOF
[xin_0]
file=/home/${TARGET_USER}/Pictures/Wallpapers/debcraft-default.png
mode=5
bgcolor=#1e1e2e
NITEOF

cat > /home/${TARGET_USER}/.config/nitrogen/nitrogen.cfg << 'NITEOF'
[geometry]
posx=0
posy=0
sizex=400
sizey=300

[nitrogen]
view=icon
recurse=true
sort=alpha
icon_caps=false
dirs=/home/live/Pictures/Wallpapers;
NITEOF

# =============================================================================
# Step 5: Configure shell (zsh + starship prompt)
# =============================================================================
echo "[DebCraft::Desktop] Configuring shell..."

# Set zsh as default shell
chsh -s /usr/bin/zsh "${TARGET_USER}" 2>/dev/null || true

# .zshrc
cat > /home/${TARGET_USER}/.zshrc << 'ZSHRC'
# ═══════════════════════════════════════════════════════════
# DebCraft ZSH Configuration
# ═══════════════════════════════════════════════════════════

# Starship prompt (if installed, otherwise fallback)
if command -v starship &>/dev/null; then
    eval "$(starship init zsh)"
else
    PROMPT='%F{blue}%n@%m%f %F{green}%~%f %# '
fi

# ── History ──────────────────────────────────────────────
HISTSIZE=10000
SAVEHIST=10000
HISTFILE=~/.zsh_history
setopt SHARE_HISTORY
setopt HIST_IGNORE_ALL_DUPS
setopt HIST_SAVE_NO_DUPS
setopt HIST_IGNORE_SPACE
setopt APPEND_HISTORY
setopt INC_APPEND_HISTORY_TIME

# ── Key bindings ─────────────────────────────────────────
bindkey -e
bindkey '^[[1;5C' forward-word
bindkey '^[[1;5D' backward-word
bindkey '^H' backward-kill-word
bindkey '^[[3~' delete-char

# ── Aliases — Navigation ─────────────────────────────────
alias ls='eza --icons --group-directories-first 2>/dev/null || ls --color=auto'
alias ll='eza -la --icons --group-directories-first 2>/dev/null || ls -la --color=auto'
alias la='eza -a --icons --group-directories-first 2>/dev/null || ls -a --color=auto'
alias lt='eza --tree --icons --level=2 2>/dev/null || tree -L 2'
alias ..='cd ..'
alias ...='cd ../..'
alias cls='clear'

# ── Aliases — Shortcuts ─────────────────────────────────
alias cat='bat --style=plain 2>/dev/null || cat'
alias grep='rg 2>/dev/null || grep --color=auto'
alias find='fd 2>/dev/null || find'
alias top='btop 2>/dev/null || htop'
alias vim='nvim'
alias vi='nvim'
alias nano='vim'
alias ports='ss -tulanp'
alias update='sudo apt update && sudo apt upgrade -y'

# ── Aliases — Git ────────────────────────────────────────
alias gs='git status'
alias ga='git add'
alias gc='git commit'
alias gp='git push'
alias gl='git log --oneline --graph --decorate'
alias gd='git diff'

# ── Aliases — Quick cd ──────────────────────────────────
alias cdd='cd ~/Desktop'
alias cddoc='cd ~/Documents'
alias cddl='cd ~/Downloads'
alias cdmus='cd ~/Music'
alias cdpic='cd ~/Pictures'

# ── Aliases — System info ───────────────────────────────
if command -v fastfetch &>/dev/null; then
    alias neofetch='fastfetch'
    alias sysinfo='fastfetch'
fi

# ── Path ────────────────────────────────────────────────
export PATH="$HOME/.local/bin:$PATH"

# ── Auto-start bspwm on tty1 ────────────────────────────
if [[ -z "$DISPLAY" ]] && [[ $(tty) == /dev/tty1 ]]; then
    exec startx ~/.xinitrc
fi
ZSHRC

# .bashrc (fallback for root or non-zsh users)
cat > /home/${TARGET_USER}/.bashrc << 'BASHRC'
# DebCraft Bash Configuration
if command -v starship &>/dev/null; then
    eval "$(starship init bash)"
fi

alias ls='eza --icons --group-directories-first 2>/dev/null || ls --color=auto'
alias ll='eza -la --icons --group-directories-first 2>/dev/null || ls -la --color=auto'
alias cat='bat --style=plain 2>/dev/null || cat'
alias grep='rg 2>/dev/null || grep --color=auto'

if command -v fastfetch &>/dev/null; then
    alias neofetch='fastfetch'
fi

alias update='sudo apt update && sudo apt upgrade -y'
BASHRC

# =============================================================================
# Step 6: Create .xinitrc (X session startup)
# =============================================================================
cat > /home/${TARGET_USER}/.xinitrc << 'XINITRC'
#!/bin/bash
# DebCraft — X init script (startx / SDDM session)

# Set DPI
xrandr --dpi 96 2>/dev/null || true

# Set cursor
xsetroot -cursor_name left_ptr 2>/dev/null || true

# Disable screen blanking
xset s off
xset -dpms
xset s noblank

# Load X resources
[[ -f ~/.Xresources ]] && xrdb -merge ~/.Xresources

# Restore wallpaper
nitrogen --restore &

# Start compositor
picom --config ~/.config/picom/picom.conf &

# Start notification daemon
dunst -config ~/.config/dunst/dunstrc &

# Start polybar
~/.config/polybar/launch.sh &

# Start dock
plank &

# Start network applet
nm-applet &

# Start bspwm
exec bspwm
XINITRC

# =============================================================================
# Step 7: Create .xprofile (loaded by SDDM/display managers)
# =============================================================================
cat > /home/${TARGET_USER}/.xprofile << 'XPROFILE'
#!/bin/bash
# DebCraft — X profile (environment variables for GUI sessions)

# Qt theme
export QT_QPA_PLATFORMTHEME=qt5ct
export QT_STYLE_OVERRIDE=kvantum

# GTK theme
export GTK_THEME=Catppuccin-Mocha-Standard

# Cursor
export XCURSOR_THEME=Bibata-Modern-Classic
export XCURSOR_SIZE=24

# Default applications
export EDITOR=nvim
export VISUAL=nvim
export TERMINAL=alacritty
export BROWSER=firefox-esr

# Java AWT fix for non-reparenting WMs
export _JAVA_AWT_WM_NONREPARENTING=1

# Input method (uncomment if needed)
# export GTK_IM_MODULE=ibus
# export QT_IM_MODULE=ibus
# export XMODIFIERS=@im=ibus
XPROFILE

# =============================================================================
# Step 8: Create .Xresources (terminal/X resources)
# =============================================================================
cat > /home/${TARGET_USER}/.Xresources << 'XRESOURCES'
! DebCraft — X Resources
XTerm*background: #1e1e2e
XTerm*foreground: #cdd6f4
XTerm*cursorColor: #f5e0dc
XTerm*font: JetBrains Mono Nerd Font-12
XTerm*faceName: JetBrains Mono Nerd Font
XTerm*faceSize: 12

! Xft settings
Xft.dpi: 96
Xft.antialias: true
Xft.hinting: true
Xft.hintstyle: hintslight
Xft.rgba: rgb
XRESOURCES

# =============================================================================
# Step 9: SDDM bspwm session file
# =============================================================================
echo "[DebCraft::Desktop] Configuring SDDM..."

mkdir -p /usr/share/xsessions
cat > /usr/share/xsessions/bspwm.desktop << 'EOF'
[Desktop Entry]
Name=bspwm
Comment=Binary space partitioning window manager
Exec=bspwm
Type=Application
DesktopNames=bspwm
Keywords=tiling;wm;window;manager;
EOF

# SDDM config
mkdir -p /etc/sddm.conf.d
cat > /etc/sddm.conf.d/debcraft.conf << 'EOF'
[Theme]
Current=breeze
CursorTheme=Bibata-Modern-Classic

[General]
Numlock=on
RebootCommand=systemctl reboot
HaltCommand=systemctl poweroff
EOF

# =============================================================================
# Step 10: Default applications (mimeapps)
# =============================================================================
echo "[DebCraft::Desktop] Setting up default applications..."

mkdir -p /home/${TARGET_USER}/.local/share/applications
cat > /home/${TARGET_USER}/.local/share/applications/mimeapps.list << 'MIMEEOF'
[Default Applications]
x-scheme-handler/http=firefox-esr.desktop
x-scheme-handler/https=firefox-esr.desktop
x-scheme-handler/ftp=firefox-esr.desktop
text/html=firefox-esr.desktop
image/png=feh.desktop
image/jpeg=feh.desktop
image/gif=feh.desktop
application/pdf=evince.desktop
video/mp4=mpv.desktop
audio/mpeg=mpv.desktop
inode/directory=thunar.desktop
MIMEEOF

# =============================================================================
# Step 11: Fastfetch configuration
# =============================================================================
echo "[DebCraft::Desktop] Configuring fastfetch..."

mkdir -p /home/${TARGET_USER}/.config/fastfetch

cat > /home/${TARGET_USER}/.config/fastfetch/config.jsonc << 'FASTFETCHEOF'
{
    "$schema": "https://github.com/fastfetch-cli/fastfetch/raw/dev/doc/json_schema.json",
    "logo": {
        "type": "auto",
        "source": "~/.config/fastfetch/debcraft.txt",
        "width": 32,
        "height": 16,
        "padding": {
            "top": 1,
            "left": 2,
            "right": 4
        }
    },
    "display": {
        "separator": "  ",
        "color": {
            "keys": "blue"
        }
    },
    "modules": [
        "title",
        "separator",
        "os",
        "kernel",
        "packages",
        "shell",
        "de",
        "wm",
        "terminal",
        "cpu",
        "gpu",
        "memory",
        "disk",
        "swap",
        "locale",
        "uptime",
        "break",
        "colors"
    ]
}
FASTFETCHEOF

# DebCraft ASCII logo
cat > /home/${TARGET_USER}/.config/fastfetch/debcraft.txt << 'LOGOEOF'
       ____                  __        __
      / __ \____ ___  ____  / /_____  / /_
     / / / / __ `__ \/ __ \/ __/ _ \/ __/
    / /_/ / / / / / / / / / /_/  __/ /_
    \____/_/ /_/ /_/_/ /_/\__/\___/\__/
LOGOEOF

# =============================================================================
# Step 12: Fix permissions
# =============================================================================
echo "[DebCraft::Desktop] Fixing permissions..."
chown -R ${TARGET_USER}:${TARGET_USER} /home/${TARGET_USER}
chmod +x /home/${TARGET_USER}/.xinitrc
chmod +x /home/${TARGET_USER}/.xprofile

echo "[DebCraft::Desktop] Desktop environment setup complete!"