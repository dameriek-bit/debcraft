#!/usr/bin/env bash
# DebCraft — Standalone Package Installation Script
# This script can be run inside a chroot to install all DebCraft packages.
# It is NOT used by build.sh directly (which handles installs inline),
# but is provided as a utility for manual chroot setups.
#
# Usage (inside chroot):
#   /tmp/install-packages.sh              # Base + desktop + theming only
#   /tmp/install-packages.sh true         # + NVIDIA drivers
#

set -e

INCLUDE_NVIDIA="${1:-false}"

echo "[DebCraft] Installing packages..."

export DEBIAN_FRONTEND=noninteractive

# =============================================================================
# Helper function
# =============================================================================
install_list() {
    local listfile="$1"
    local description="$2"
    if [[ ! -f "$listfile" ]]; then
        echo "[DebCraft] WARNING: $listfile not found, skipping"
        return 0
    fi

    echo "[DebCraft] Installing ${description}..."
    local pkgs
    pkgs=$(grep -vE '^\s*#|^\s*$' "$listfile" | tr '\n' ' ')
    if [[ -n "$pkgs" ]]; then
        apt-get install -y --no-install-recommends $pkgs 2>&1 | tail -5 || true
    fi
}

# =============================================================================
# Enable non-free and contrib repositories
# =============================================================================
echo "[DebCraft] Configuring APT sources..."
cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian bookworm main contrib non-free non-free-firmware
deb http://deb.debian.org/debian-security bookworm-security main contrib non-free non-free-firmware
deb http://deb.debian.org/debian bookworm-updates main contrib non-free non-free-firmware
EOF

# Backports for Calamares
cat > /etc/apt/sources.list.d/backports.list << 'EOF'
deb http://deb.debian.org/debian bookworm-backports main contrib non-free
EOF

apt-get update

# =============================================================================
# Install package lists
# =============================================================================
install_list /tmp/base.list    "base system"
install_list /tmp/desktop.list "desktop environment"
install_list /tmp/theming.list "themes and extras"

# =============================================================================
# Calamares installer (from backports)
# =============================================================================
echo "[DebCraft] Installing Calamares installer..."
apt-get install -y -t bookworm-backports calamares 2>/dev/null || \
    apt-get install -y calamares 2>/dev/null || true

# =============================================================================
# NVIDIA drivers (if requested)
# =============================================================================
if [[ "$INCLUDE_NVIDIA" == "true" ]]; then
    echo "[DebCraft] Installing NVIDIA driver packages..."
    install_list /tmp/nvidia.list "NVIDIA drivers"
fi

# =============================================================================
# Install tools not available in Debian 12 repos
# =============================================================================
echo "[DebCraft] Installing upstream tools (fastfetch, starship, eza)..."

# fastfetch — prebuilt binary
if ! command -v fastfetch &>/dev/null; then
    ARCH=$(uname -m)
    case "$ARCH" in
        x86_64) FASTFETCH_ARCH="x86_64" ;;
        aarch64) FASTFETCH_ARCH="aarch64" ;;
    esac
    if [[ -n "${FASTFETCH_ARCH:-}" ]]; then
        curl -sL "https://github.com/fastfetch-cli/fastfetch/releases/download/2.8.0/fastfetch-linux-${FASTFETCH_ARCH}.tar.gz" | \
            tar xz -C /tmp/ 2>/dev/null
        [[ -f "/tmp/fastfetch/usr/bin/fastfetch" ]] && \
            cp /tmp/fastfetch/usr/bin/fastfetch /usr/local/bin/ && chmod +x /usr/local/bin/fastfetch
        rm -rf /tmp/fastfetch
    fi
fi

# starship — prebuilt binary
if ! command -v starship &>/dev/null; then
    curl -sSfL "https://starship.rs/install.sh" | sh -s -- -y -b /usr/local/bin 2>/dev/null || true
fi

# eza — modern ls replacement
if ! command -v eza &>/dev/null; then
    ARCH=$(uname -m)
    case "$ARCH" in
        x86_64) EZA_ARCH="x86_64-unknown-linux-musl" ;;
        aarch64) EZA_ARCH="aarch64-unknown-linux-musl" ;;
    esac
    if [[ -n "${EZA_ARCH:-}" ]]; then
        curl -sL "https://github.com/eza-community/eza/releases/latest/download/eza_${EZA_ARCH}.tar.gz" | \
            tar xz -C /usr/local/bin/ 2>/dev/null || true
    fi
fi

# cbatticon — battery icon
apt-get install -y --no-install-recommends cbatticon 2>/dev/null || true

# =============================================================================
# Catppuccin GTK theme (from source)
# =============================================================================
echo "[DebCraft] Installing Catppuccin GTK theme..."
if ! dpkg -l | grep -q catppuccin-gtk-theme 2>/dev/null; then
    mkdir -p /tmp/catppuccin-build && cd /tmp/catppuccin-build
    apt-get install -y -qq git sassc optipng 2>/dev/null || true
    git clone --depth 1 https://github.com/catppuccin/gtk.git 2>/dev/null || true
    if [[ -d gtk ]]; then
        cd gtk && ./install.sh -d -c mocha 2>/dev/null || true
    fi
    cd / && rm -rf /tmp/catppuccin-build
fi

echo "[DebCraft] All packages installed successfully!"