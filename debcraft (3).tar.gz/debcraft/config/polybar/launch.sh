#!/usr/bin/env bash
# DebCraft — Polybar launch script
# Launches polybar on all connected monitors

# Terminate already running bar instances
killall -q polybar

# Wait until processes have been shut down
while pgrep -x polybar >/dev/null; do sleep 1; done

# Get all connected monitors
MONITORS=$(xrandr --query 2>/dev/null | grep " connected" | cut -d" " -f1)

if [[ -z "$MONITORS" ]]; then
    echo "No monitors detected. Using default."
    MONITORS="eDP-1"
fi

# Launch on primary monitor
PRIMARY=$(echo "$MONITORS" | head -n1)
export MONITOR="$PRIMARY"
export MONITOR2=""

# Launch secondary bar on additional monitors (if any)
MONITOR_COUNT=$(echo "$MONITORS" | wc -l)
if [[ $MONITOR_COUNT -gt 1 ]]; then
    SECONDARY=$(echo "$MONITORS" | tail -n1)
    export MONITOR2="$SECONDARY"
    MONITOR="$SECONDARY" polybar -q secondary &
    echo "Polybar launched on secondary monitor: $SECONDARY"
fi

# Launch main bar on primary monitor
MONITOR="$PRIMARY" polybar -q main &
echo "Polybar launched on primary monitor: $PRIMARY"