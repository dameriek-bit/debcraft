#!/usr/bin/env bash
# DebCraft — Rofi Power Menu
# Shows a rofi dmenu with power options

# Menu options
shutdown="󰐥  Shutdown"
reboot="󰜉  Reboot"
lock="󰍃  Lock"
logout="󰌾  Logout"
suspend="󰤄  Suspend"
cancel="✕  Cancel"

options="$shutdown\n$reboot\n$lock\n$logout\n$suspend\n$cancel"

# Show rofi menu (default to Cancel selected so accidental clicks are safe)
selection=$(echo -e "$options" | rofi -dmenu -p "Power" \
    -theme ~/.config/rofi/launchers/type-1/launcher.rasi \
    -selected-row 5)

case "$selection" in
    "$shutdown")  systemctl poweroff ;;
    "$reboot")    systemctl reboot ;;
    "$lock")      i3lock -c 1e1e2e || betterlockscreen -l dimblur ;;
    "$logout")    bspc quit ;;
    "$suspend")   systemctl suspend ;;
    "$cancel")    ;;
esac