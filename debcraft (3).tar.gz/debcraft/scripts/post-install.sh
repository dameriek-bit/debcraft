#!/usr/bin/env bash
# DebCraft — Post-Installation Script
# Run this on an installed DebCraft system to set up a new user with full config
#
# Usage:
#   sudo ./post-install.sh <username>
#
# This copies configs from /etc/skel to the target user's home directory,
# creates XDG directories, and sets up the wallpaper.

set -e

USERNAME="${1:-}"

if [[ -z "$USERNAME" ]]; then
    echo "Usage: sudo $0 <username>"
    echo ""
    echo "Sets up DebCraft desktop configuration for the given user."
    echo "Copies configs from /etc/skel and creates user directories."
    exit 1
fi

USER_HOME="/home/${USERNAME}"
SKEL_DIR="/etc/skel"

echo "╔══════════════════════════════════════════╗"
echo "║  DebCraft Post-Install Configuration     ║"
echo "╚══════════════════════════════════════════╝"
echo ""
echo "Target user: ${USERNAME}"

# Ensure user exists
if ! id "$USERNAME" &>/dev/null; then
    echo "[*] User '${USERNAME}' does not exist. Creating..."
    useradd -m -s /bin/zsh -G sudo,audio,video,plugdev,netdev,cdrom,autologin "$USERNAME"
    echo "${USERNAME}:${USERNAME}" | chpasswd
    echo "[*] User created with default password: ${USERNAME} (CHANGE IT!)"
fi

# Copy skel configs
if [[ -d "${SKEL_DIR}/.config" ]]; then
    echo "[*] Copying configuration from /etc/skel..."
    cp -r "${SKEL_DIR}/.config"   "${USER_HOME}/" 2>/dev/null || true
    cp "${SKEL_DIR}/.zshrc"      "${USER_HOME}/"  2>/dev/null || true
    cp "${SKEL_DIR}/.bashrc"     "${USER_HOME}/"  2>/dev/null || true
    cp "${SKEL_DIR}/.xinitrc"    "${USER_HOME}/"  2>/dev/null || true
    cp "${SKEL_DIR}/.xprofile"   "${USER_HOME}/"  2>/dev/null || true
    cp "${SKEL_DIR}/.Xresources" "${USER_HOME}/"  2>/dev/null || true
    chown -R "${USERNAME}:${USERNAME}" "${USER_HOME}/.config" \
        "${USER_HOME}/.zshrc" "${USER_HOME}/.bashrc" \
        "${USER_HOME}/.xinitrc" "${USER_HOME}/.xprofile" \
        "${USER_HOME}/.Xresources" 2>/dev/null || true
else
    echo "[!] WARNING: /etc/skel/.config not found. No configs to copy."
    echo "    The ISO may not have been built with DebCraft configs."
fi

# Create XDG user directories
echo "[*] Creating user directories..."
mkdir -p "${USER_HOME}"/{Desktop,Documents,Downloads,Music,Videos}
mkdir -p "${USER_HOME}/Pictures/Screenshots"
mkdir -p "${USER_HOME}/Pictures/Wallpapers"
chown -R "${USERNAME}:${USERNAME}" "${USER_HOME}"

# Set up nitrogen wallpaper config
echo "[*] Configuring wallpaper..."
mkdir -p "${USER_HOME}/.config/nitrogen"
cat > "${USER_HOME}/.config/nitrogen/bg-saved.cfg" << EOF
[xin_0]
file=${USER_HOME}/Pictures/Wallpapers/debcraft-default.png
mode=5
bgcolor=#1e1e2e
EOF
chown -R "${USERNAME}:${USERNAME}" "${USER_HOME}/.config/nitrogen"

# Set correct shell
chsh -s /bin/zsh "$USERNAME" 2>/dev/null || true

# Update XDG user directories
su - "$USERNAME" -c "xdg-user-dirs-update" 2>/dev/null || true

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║  Configuration complete!                 ║"
echo "║                                          ║"
echo "║  Log out and log back in, or run:        ║"
echo "║    su - ${USERNAME}                        ║"
echo "╚══════════════════════════════════════════╝"