#!/usr/bin/env bash
# DebCraft — Build Environment Check
# Validates the build environment and all project files
#
# Usage:
#   sudo ./check-build-env.sh     # Run as root for full check
#   ./check-build-env.sh          # Run as user for file check only

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" 2>/dev/null && pwd)"
if [[ -z "$SCRIPT_DIR" ]]; then
    SCRIPT_DIR="$(dirname "$0")"
fi

# Project root is one level up from scripts/
PROJECT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

echo "╔══════════════════════════════════════════════════════╗"
echo "║  DebCraft Build Environment Check                   ║"
echo "║  Project: ${PROJECT_DIR}"
echo "╚══════════════════════════════════════════════════════╝"
echo ""

PASS=0
FAIL=0

check_result() {
    if [[ "$1" == "ok" ]]; then
        echo -e "  \033[32m[OK]\033[0m   $2"
        PASS=$((PASS + 1))
    else
        echo -e "  \033[31m[FAIL]\033[0m $2"
        FAIL=$((FAIL + 1))
    fi
}

# ── Root check ──
if [[ $EUID -eq 0 ]]; then
    check_result ok "Running as root"
else
    check_result fail "Not running as root (some checks skipped)"
fi

# ── Required tools ──
echo ""
echo "=== Build Tools ==="
TOOLS=(debootstrap mksquashfs xorriso grub-mkimage)
for tool in "${TOOLS[@]}"; do
    if command -v "$tool" &>/dev/null; then
        check_result ok "$tool: $(command -v "$tool")"
    else
        check_result fail "$tool: NOT FOUND"
    fi
done

# ── Project files ──
echo ""
echo "=== Project Files ==="
FILES=(
    # Package lists
    "packages/base.list"
    "packages/desktop.list"
    "packages/nvidia.list"
    "packages/theming.list"
    # Build scripts
    "build.sh"
    "build-both.sh"
    # Desktop configs
    "config/bspwm/bspwmrc"
    "config/sxhkd/sxhkdrc"
    "config/polybar/config.ini"
    "config/polybar/launch.sh"
    "config/picom/picom.conf"
    "config/rofi/launchers/type-1/launcher.rasi"
    "config/rofi/powermenu/powermenu.sh"
    "config/alacritty/alacritty.toml"
    "config/dunst/dunstrc"
    "config/gtk-3.0/settings.ini"
    "config/gtk-4.0/settings.ini"
    "config/starship/starship.toml"
    # Chroot scripts
    "chroot/install-packages.sh"
    "chroot/install-nvidia.sh"
    "chroot/setup-desktop.sh"
    # Installer
    "installer/settings.conf"
    "installer/branding/debcraft.branding"
    "installer/modules/partition.conf"
    "installer/modules/unpackfs.conf"
    "installer/modules/users.conf"
    "installer/modules/displaymanager.conf"
    "installer/modules/grubcfg.conf"
    "installer/modules/locale.conf"
    "installer/modules/packages.conf"
    "installer/modules/networkcfg.conf"
    "installer/modules/shellprocess_preinstall.conf"
    "installer/modules/shellprocess_postinstall.conf"
    "installer/modules/shellprocess_finalize.conf"
    # Utility scripts
    "scripts/post-install.sh"
    "scripts/generate-grub-theme.sh"
)

for f in "${FILES[@]}"; do
    if [[ -f "${PROJECT_DIR}/${f}" ]]; then
        check_result ok "${f}"
    else
        check_result fail "${f} — MISSING"
    fi
done

# ── Summary ──
echo ""
echo "╔══════════════════════════════════════════════════════╗"
TOTAL=$((PASS + FAIL))
echo "║  Total: ${TOTAL}  |  Pass: ${PASS}  |  Fail: ${FAIL}"
if [[ $FAIL -eq 0 ]]; then
    echo "║  Status: READY TO BUILD"
else
    echo "║  Status: ${FAIL} check(s) failed"
fi
echo "╚══════════════════════════════════════════════════════╝"

[[ $FAIL -gt 0 ]] && exit 1 || exit 0