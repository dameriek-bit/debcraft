#!/usr/bin/env bash
# DebCraft — Generate GRUB Theme
# Creates a Catppuccin Mocha themed GRUB bootloader
#
# Usage:
#   sudo ./generate-grub-theme.sh                  # Generates to /tmp/grub-theme/
#   sudo ./generate-grub-theme.sh /usr/share/grub/themes/debcraft  # Direct install
#
# The generated theme will be at <DEST>/debcraft/theme.txt

set -e

DEST="${1:-/tmp/grub-theme}"
FINAL_DIR="${DEST}/debcraft"

echo "[DebCraft] Generating GRUB theme..."

mkdir -p "${FINAL_DIR}"

cat > "${FINAL_DIR}/theme.txt" << 'EOF'
# ═══════════════════════════════════════════════════════════
# DebCraft GRUB Theme — Catppuccin Mocha
# ═══════════════════════════════════════════════════════════

# Title
title-font: "DejaVu Sans Bold 16"
title-color: "#cdd6f4"

# Messages
message-font: "DejaVu Sans 14"
message-color: "#cdd6f4"
message-bg-color: "#1e1e2e"

# Desktop
desktop-color: "#1e1e2e"
desktop-image: ""

# Menu
menu-color-normal: "#cdd6f4"
menu-color-highlight: "#1e1e2e"
menu-bg-color: "#1e1e2e"
menu-border-color: "#313244"
menu-border-width: 2

# Items
item-color: "#cdd6f4"
item-selected-color: "#1e1e2e"
item-font: "DejaVu Sans 14"
item-selected-font: "DejaVu Sans Bold 14"
item-selected-bg-color: "#89b4fa"
item-selected-fg-color: "#1e1e2e"
item-height: 36
item-padding: 8
item-icon-width: 40
item-spacing: 12

# Scrollbar
scrollbar-color: "#313244"
scrollbar-thumb-color: "#89b4fa"
scrollbar-width: 12

# Progress bar
progress-bar-color: "#89b4fa"
progress-bar-bg-color: "#313244"
progress-bar-border-color: "#313244"
progress-bar-height: 8
progress-bar-pad: 0

# Boot menu geometry
boot-menu-width: 500
boot-menu-height: 400
boot-menu-left: 50%-250
boot-menu-top: 50%-200

# Terminal
terminal-border-color: "#313244"
terminal-font: "DejaVu Sans Mono 14"

# Label
label-color: "#89b4fa"
label-bg-color: "transparent"

# Help text at bottom
+ label {
    left = 10%
    top = 70%
    width = 80%
    align = center
    color = "#6c7086"
    font = "DejaVu Sans 12"
    text = "Select an entry and press Enter to boot"
}
EOF

echo "[DebCraft] GRUB theme generated at: ${FINAL_DIR}/"
echo ""

if [[ "$DEST" != "/tmp/grub-theme" ]]; then
    echo "[DebCraft] Theme installed to: ${FINAL_DIR}"
else
    echo "[DebCraft] To install, run:"
    echo "  sudo cp -r ${FINAL_DIR} /usr/share/grub/themes/debcraft"
    echo ""
    echo "[DebCraft] Then add to /etc/default/grub:"
    echo '  GRUB_THEME="/usr/share/grub/themes/debcraft/theme.txt"'
    echo ""
    echo "[DebCraft] Then update GRUB:"
    echo "  sudo update-grub"
fi